package Positional_game;

import java.util.List;

class Player implements Runnable
{
    private String name;
    private Game game;

    Player(String name) {
        this.name = name;
    }
    private boolean extractToken() throws InterruptedException {
        List extracted = game.getToken().extractToken(1);
        if (extracted.isEmpty()) {
            return false;
        }
        StringBuilder token = new StringBuilder();
        int m;
        for (int i = 0; i <  m; i++) {
            token.append(extracted.get(0));
        }
        game.getBoard().addToken(this, token.toString());
        Thread.sleep(10000);
        return true;
    }


    public String getName() {
        return name;
    }

    public void setName( String name ) {
        this.name = name;
    }

    public Game getGame() {
        return game;
    }

    public void setGame( Game game ) {
        this.game = game;
    }


    @Override
    public void run() {
        public String toString() {
            return name;
        }
    }

    @Override
        public void run() {
            while (true) {
                try {
                    if (!extractToken()) {
                        break;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
}