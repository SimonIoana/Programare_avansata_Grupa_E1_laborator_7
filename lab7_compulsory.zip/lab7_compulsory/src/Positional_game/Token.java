package Positional_game;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

class Token
 {
  private final Queue<Character> token = new LinkedList<>();

  Token () {
   int  m;
   for(char i = 0; i <= m ; ++i ) {
    token.add(i);
   }
  }
  public synchronized final List<Character> extractToken(int n ) {
   List<Character> extracted = new ArrayList<>();
   for (int i = 0; i < n; i++) {
    if (token.isEmpty()) break;
    extracted.add(token.poll());
   }
   return extracted;
  }
 }