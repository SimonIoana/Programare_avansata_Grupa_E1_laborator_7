package Positional_game;

import java.util.ArrayList;
import java.util.List;

public class Game
{
    private Token token;
    private Board board;
    private final List<Player> players = new ArrayList<>();
    public void addPlayer(Player player)
    {
        players.add(player);
        player.setGame(this);
    }
    public Board getBoard() {
        return board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }
    public Token getToken() {
        return token;
    }

    public void setToken(Token token) {
        this.token = token;
    }
    public List<Player> getPlayers() {
        return players;
    }

    public void start() {
        for( Player p : players ) {
            new Thread(p).start();
        }
    }


}