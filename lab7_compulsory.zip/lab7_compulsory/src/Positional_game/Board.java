package Positional_game;

import java.util.ArrayList;
import java.util.List;

class Board
{
    private final List<String> tokenList;

    Board() {
        tokenList = new ArrayList<>();
    }

    synchronized final void addToken ( Player p , String token) throws NullPointerException {
        if ( token == null ) {
            throw new NullPointerException("Player extracts a token from the board!");
        }
        if( p == null ) {
            throw new NullPointerException("An existing player must extracts tokens successively from the board!");
        }
        tokenList.add(token);
        System.out.println("Player " + p.getName() + " and the token " + token );
    }

}