package Positional_game;

import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.List;
// Am creat o tabla de joc , din care un jucator va trebui sa extraga cate un token de fiecare data si trebuie sa creeze cu ele "a complete arithmetic progression".
class Main
{
    public static void main(String[] args) {
        Game game = new Game();
        game.setBoard(new Board());
        try {
            game.setToken(new Token());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        game.addPlayer(new Player("Player 1"));
        game.addPlayer(new Player("Player 2"));
        game.addPlayer(new Player("Player 3"));
        game.start();
    }
}